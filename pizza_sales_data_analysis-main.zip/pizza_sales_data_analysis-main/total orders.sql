-- Retrieve the total number of orders placed.

select count(order_details_id) from order_details;